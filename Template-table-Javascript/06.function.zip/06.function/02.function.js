function hello(data) {

    document.write(`<h1>Hello : ${data}</h1>`);
}

hello("HTML");
hello("CSS");
hello("JAVASCRIPT");
hello("REACT");