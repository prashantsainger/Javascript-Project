# JavaScript Function ()

**Functions are a fundamental concept in JavaScript, and they play a role in structuring and organizing code. Functions are blocks of reusable code that can be defined once and executed (called) multiple times.**

## function Type

- pre define function ex.  math()

- user define function ex. ducat()

<hr>


> define the function

> call the function

> passing the argument

> setting default value

> return the value


# Advance Function

> arrow Function

> IFFE