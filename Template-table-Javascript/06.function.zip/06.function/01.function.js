function hello() {
    console.log("Hello User");
}
function hello() {
    console.log("Hello User Ducat");
}

// let hello = function () { console.log("Hello") };

hello();


