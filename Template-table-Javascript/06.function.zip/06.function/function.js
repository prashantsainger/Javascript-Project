// console.log(user);
// Cannot access 'user' before initialization

// user = "Hello Guest";
// user = "Hello Ducat";

// document.write(user)
// console.log(user);
// console.log(user);
// console.log(user);


// define the function
function user() {

    let data = "test";
    console.log(data);
    document.write(`<h1>${data}</h1>`);
}
function user() {

    let data = "test Developer";
    console.log(data);
    document.write(`<h1>${data}</h1>`);
}

// call the function
// Identifier 'user' has already been declared
user();
user();
user();
user();











